# Lumiere for 2.81

## Interactive Lighting add-on for Blender 
Wiki : https://github.com/clarkx/Lumiere-for-2.8//wiki

## Installation :
- Click on the "Clone or download" button
- Click on "Download ZIP",
- In the zip file rename the directory "Lumiere-for-2.81-master" to "Lumiere"
- Then rename the zip file "Lumiere-for-2.81-master.zip" "Lumiere.zip",
- In the blender preferences, click on the "Add-ons" tab then on "Install..." and select the zip file,
- A new tab "Lumiere" should appear.

![Download_zip](https://user-images.githubusercontent.com/10100090/66702026-446a1b00-ed03-11e9-9247-45f02a75f5d2.gif)
